// Minimal background script to keep the extension running
